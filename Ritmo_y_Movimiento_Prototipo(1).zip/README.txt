RITMO Y MOVIMIENTO — PROTOTIPO UNIVERSITARIO

1. Abre index.html en un navegador.
2. Usa el botón "Administración" al final de la página.
3. Contraseña de demostración: ritmo2026
4. Desde el panel puedes ver registros, agregar/eliminar eventos, fotos, integrantes y estilos.

IMPORTANTE:
Es un prototipo académico. Los registros y cambios se guardan localmente en el navegador (localStorage); no es una base de datos en Internet.
